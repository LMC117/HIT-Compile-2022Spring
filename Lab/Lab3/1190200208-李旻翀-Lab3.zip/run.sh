#!usr/bin/bash

flex -o ./lex.yy.c ./lexical.l
bison -o ./syntax.tab.c -d -v ./syntax.y
gcc -c ./syntax.tab.c -o ./syntax.tab.o
gcc -std=c99   -c -o interim.o interim.c
gcc -std=c99   -c -o main.o main.c
gcc -std=c99   -c -o semantic.o semantic.c
gcc -o parser ./interim.o ./main.o ./semantic.o ./syntax.tab.o -lfl -ly
