#ifndef NODE_H
#define NODE_H

struct Node
{
    struct Node *child;   //子节点
    struct Node *brother; //右兄弟节点
    int linenumber;       //记录行号，用于打印
    char name[30];        //记录该单元规定的名字(token)
    int flag;            // flag=0为词法单元，flag=1为语法单元，用于输出判断
    union
    {
        char char_name[30];
        int int_number;  //语法单元由空串生成时int_number=0,其余为1
        float float_number;
    }; //记录附加信息
    
};

#endif
