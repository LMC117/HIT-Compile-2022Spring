#!usr/bin/bash

flex -o ./lex.yy.c ./lexical.l
bison -o ./syntax.tab.c -d -v ./syntax.y
gcc -c ./syntax.tab.c -o ./syntax.tab.o
gcc -o parser ./main.o ./semantic.o ./syntax.tab.o -lfl -ly
