#include "lab1.h"

int i;

Ast create_ast(char *name, int num, ...)
{
    tnode father = (tnode)malloc(sizeof(struct ASTnode)); // father node
    tnode temp = (tnode)malloc(sizeof(struct ASTnode));  // child node
    if (!father)
    {
        yyerror("error when creating ASTnode");
        exit(0);
    }
    father->name = name;

    va_list list;  // parameter list
    va_start(list, num);  // initialize

    // 若当前节点还有子节点，进行添加
    if (num > 0)  
    {
        temp = va_arg(list, tnode);  // 检索下一个参数，作为first child
        setChildTag(temp);
        father->fchild = temp;
        father->line = temp->line;

        // 若有1个以上的节点，则继续进行添加
        if (num >= 2)
        {
            for (i = 0; i < num - 1; ++i)
            {
                temp->next = va_arg(list, tnode);
                temp = temp->next;
                setChildTag(temp);  // 若该节点为其他节点的子节点，设置节点状态
            }
        }
    }
    else //当前节点是终结符或者null，将对应的值存入union
    {
        father->line = va_arg(list, int);
        if ((!strcmp(name, "TYPE")) || (!strcmp(name, "ID")))
        {
            char *str;
            str = (char *)malloc(sizeof(char) * 40);
            strcpy(str, yytext);
            father->id_type = str;
        }
        else if (!strcmp(name, "INT"))
            father->int_value = atoi(yytext);
        else
            father->float_value = atof(yytext);
    }
    return father;
}

// 先序遍历
void Preorder(Ast ast, int PO_num)
{
    if (ast != NULL)
    {
        for (i = 0; i < PO_num; i++)  // 以"  "表示出层次结构
            printf("  ");
        if (ast->line != -1)
        {
            printf("%s", ast->name);  // 输出节点类型
            // 根据不同类型打印节点数据
            if ((!strcmp(ast->name, "ID")) || (!strcmp(ast->name, "TYPE")))
                printf(": %s", ast->id_type);
            else if (!strcmp(ast->name, "INT"))
                printf(": %d", ast->int_value);
            else if (!strcmp(ast->name, "FLOAT"))
                printf(": %f", ast->float_value);
            else // 非叶节点：打印行号
                printf("(%d)", ast->line);
        }
        printf("\n");
        Preorder(ast->fchild, PO_num + 1);  // 对first child递归遍历
        Preorder(ast->next, PO_num);  // 对right child递归遍历
    }
}

// 错误处理函数
void yyerror(char *msg)
{
    flag = 1;
    fprintf(stderr, "Error type B at Line %d: %s\n", yylineno, msg);
}

// 设置子节点状态
void setChildTag(tnode node)
{
    int i;
    for (i = 0; i < node_num; i++)
        if (node_list[i] == node)
            ischild[i] = 1;
}

int main(int argc, char **argv)
{
    int j;
    if (argc < 2)
        return 1;
    for (i = 1; i < argc; i++)
    {
        // 初始化node list
        node_num = 0;
        memset(node_list, 0, sizeof(tnode) * 5000);
        memset(ischild, 0, sizeof(int) * 5000);
        flag = 0;

        FILE *f = fopen(argv[i], "r");
        if (!f)
        {
            perror(argv[i]);
            return 1;
        }
        yyrestart(f);
        yyparse();
        fclose(f);

        // 对非子节点进行遍历
        if (flag)
            continue;
        for (j = 0; j < node_num; j++)
        {
            if (ischild[j] != 1)
                Preorder(node_list[j], 0);
        }
    }
}
