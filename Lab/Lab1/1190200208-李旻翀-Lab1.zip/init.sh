#!/usr/bin/bash

bison -d lab1.y
flex lab1.l
gcc lab1.tab.c lab1.c lex.yy.c -lfl -ly -o parser
