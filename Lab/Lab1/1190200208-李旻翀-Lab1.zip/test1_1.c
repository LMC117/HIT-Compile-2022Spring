int main()
{
    int i = 1;
    int j = ~i;
}