#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <stdarg.h> 

extern int yylineno; // 行数

extern char* yytext;    // 文本

void yyerror(char *msg);  // 错误处理程序

// AST结构体
typedef struct ASTnode{
    int line;  // 行数
    char* name;  // token类型
    union{
        // 用联合体保存id或type（int/float）
        char* id_type;
        // int/float具体的数值（如果有）
        int int_value;
        float float_value;
    };
    struct ASTnode *fchild,*next;  // fchild：第一个孩子节点，next：兄弟节点
}* Ast,* tnode;

Ast create_ast(char* name,int num,...);  // 构造AST(节点)

void setChildTag(tnode node);  // 设置节点状态

void Preorder(Ast ast,int PO_num);  // 先序遍历语法树

int flag;  // 标志bison是否检查出错误

int node_num;  // 节点数量

int ischild[5000];  // 保存每个节点是否是孩子的flag数组

tnode node_list[5000];  // node_list，保存所有节点
